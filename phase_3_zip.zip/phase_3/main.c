#include "structCustomer.h"
#include "addCustomer.h"
#include "displayCustomers.h"
#include "saveCustomersToFile.h"
#include "loadCustomersFromFile.h"
#include "searchCustomer.h"

#include "structItemList.h"
#include "addItem.h"
#include "displayItems.h"
#include "saveItems.h"
#include "loadItems.h"
#include "searchItem.h"

#include <stdio.h>

int main() {
    // Customer and item arrays
    Customer customers[MAX_CUSTOMERS];
    int num_customers = 0;

    ItemList items[MAX_ITEMS];
    int num_items = 0;

    // Load customers and items from files
    loadCustomersFromFile(customers, &num_customers);
    loadItems(items, &num_items);

    // Menu loop
    int choice;
    do {
        printf("\n===== Billing System Menu =====\n");
        printf("1. Customer Entry\n");
        printf("2. Item Entry\n");
        printf("3. Generate Bill\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addCustomer(customers, &num_customers);
                break;
            case 2:
                addItem(items, &num_items);
                break;
            case 3:
                // Generate Bill logic goes here
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please enter a number between 1 and 4.\n");
        }
    } while (choice != 4);

    // Save customers and items to files before exiting
    saveCustomersToFile(customers, num_customers);
    saveItems(items, num_items);

    return 0;
}
