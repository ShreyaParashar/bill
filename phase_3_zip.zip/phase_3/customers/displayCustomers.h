/*#ifndef DISPLAYCUSTOMERS_H
#define DISPLAYCUSTOMERS_H

#include "structCustomer.h"

void displayCustomers(Customer customers[], int count);

#endif
*/

#ifndef DISPLAYCUSTOMERS_H
#define DISPLAYCUSTOMERS_H

#include "structCustomer.h"

void displayCustomers(Customer customers[], int count);

#endif
