/*#ifndef LOADCUSTOMERSFROMFILE_H
#define LOADCUSTOMERSFROMFILE_H

#include "structCustomer.h"

void loadCustomersFromFile(Customer customers[], int *count);

#endif*/


#ifndef LOADCUSTOMERSFROMFILE_H
#define LOADCUSTOMERSFROMFILE_H

#include "structCustomer.h"

void loadCustomersFromFile(Customer customers[], int *count);

#endif
