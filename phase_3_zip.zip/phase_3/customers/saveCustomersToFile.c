/*#include "structCustomer.h"
#include <stdio.h>


void saveCustomersToFile(Customer customers[], int count) {
    FILE *file = fopen(FILENAME, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d %s %.2f\n", customers[i].id, customers[i].name, customers[i].balance);
    }
    fclose(file);
    printf("Customer details saved to file successfully!\n");
}*/


#include "structCustomer.h"
#include <stdio.h>

void saveCustomersToFile(Customer customers[], int count) {
    FILE *file = fopen(FILENAME, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d %s %.2f\n", customers[i].id, customers[i].name, customers[i].balance);
    }
    fclose(file);
    printf("Customer details saved to file successfully!\n");
}
