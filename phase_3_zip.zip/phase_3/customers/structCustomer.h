/*#ifndef STRUCTCUSTOMER_H
#define STRUCTCUSTOMER_H

#define MAX_CUSTOMERS 100
#define NAME_LENGTH 50
#define FILENAME "customers.txt"

typedef struct {
    char name[NAME_LENGTH];
    int id;
    double balance;
} Customer;

#endif*/


#ifndef STRUCTCUSTOMER_H
#define STRUCTCUSTOMER_H

#define MAX_CUSTOMERS 100
#define NAME_LENGTH 50
#define FILENAME "customers.txt"

typedef struct {
    char name[NAME_LENGTH];
    int id;
    double balance;
} Customer;

#endif