/*#ifndef SAVECUSTOMERSTOFILE_H
#define SAVECUSTOMERSTOFILE_H

#include "structCustomer.h"

void saveCustomersToFile(Customer customers[], int count);

#endif*/

#ifndef SAVECUSTOMERSTOFILE_H
#define SAVECUSTOMERSTOFILE_H

#include "structCustomer.h"

void saveCustomersToFile(Customer customers[], int count);

#endif