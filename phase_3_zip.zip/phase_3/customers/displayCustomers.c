/*#include "displayCustomers.h"
#include <stdio.h>

void displayCustomers(Customer customers[], int count) {
    printf("\nCustomer Details:\n");
    for (int i = 0; i < count; i++) {
        printf("ID: %d\n Name: %s\n Balance: %.2f\n", customers[i].id, customers[i].name, customers[i].balance);
    }
}
*/

#include "displayCustomers.h"
#include <stdio.h>

void displayCustomers(Customer customers[], int count) {
    printf("\nCustomer Details:\n");
    for (int i = 0; i < count; i++) {
        printf("ID: %d\nName: %s\nBalance: %.2f\n", customers[i].id, customers[i].name, customers[i].balance);
    }
}
