/*#include "addCustomer.h"
#include <stdio.h>

void addCustomer(Customer customers[], int *count) {
    if (*count >= MAX_CUSTOMERS) {
        printf("Customer list is full.\n");
        return;
    }
    printf("Enter customer ID: \n");
    scanf("%d", &customers[*count].id);
    printf("Enter customer name: \n");
    scanf("%s", customers[*count].name);
    printf("Enter customer balance due: \n");
    scanf("%lf", &customers[*count].balance);
    (*count)++;
    printf("Customer details updated successfully.\n");
}*/


#include "addCustomer.h"
#include <stdio.h>

void addCustomer(Customer customers[], int *count) {
    if (*count >= MAX_CUSTOMERS) {
        printf("Customer list is full.\n");
        return;
    }
    printf("Enter customer ID: \n");
    scanf("%d", &customers[*count].id);
    printf("Enter customer name: \n");
    scanf("%s", customers[*count].name);
    printf("Enter customer balance due: \n");
    scanf("%lf", &customers[*count].balance);
    (*count)++;
    printf("Customer details updated successfully.\n");
}
