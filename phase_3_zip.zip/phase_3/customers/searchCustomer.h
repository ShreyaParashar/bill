/*#ifndef SEARCHCUSTOMER_H
#define SEARCHCUSTOMER_H

#include "structCustomer.h"

void searchCustomer(Customer customers[], int count, int id);

#endif
*/


#ifndef SEARCHCUSTOMER_H
#define SEARCHCUSTOMER_H

#include "structCustomer.h"

void searchCustomer(Customer customers[], int count, int id);

#endif
