/*typedef struct {
    char name[NAME_LENGTH];
    int id;
    double balance;
} Customer;*/