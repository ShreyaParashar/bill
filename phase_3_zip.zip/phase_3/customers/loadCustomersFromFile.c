/*#include "loadCustomersFromFile.h"
#include <stdio.h>

void loadCustomersFromFile(Customer customers[], int *count) {
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        printf("No existing customer file found. Starting with an empty list.\n");
        return;
    }
    *count = 0;
    while (fscanf(file, "%d %s %lf", &customers[*count].id, customers[*count].name, &customers[*count].balance) != EOF) {
        (*count)++;
    }
    fclose(file);
    printf("Customer details loaded successfullyy.\n");
}*/

#include "loadCustomersFromFile.h"
#include <stdio.h>

void loadCustomersFromFile(Customer customers[], int *count) {
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        printf("No existing customer file found. Starting with an empty list.\n");
        return;
    }
    *count = 0;
    while (fscanf(file, "%d %s %lf", &customers[*count].id, customers[*count].name, &customers[*count].balance) != EOF) {
        (*count)++;
    }
    fclose(file);
    printf("Customer details loaded successfully.\n");
}