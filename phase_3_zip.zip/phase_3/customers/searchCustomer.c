/*#include "searchCustomer.h"
#include <stdio.h>

void searchCustomer(Customer customers[], int count, int id) {
    for (int i = 0; i < count; i++) {
        if (customers[i].id == id) {
            printf("Customer found----------- /nID: %d\n Name: %s\n Balance: %.2f\n", customers[i].id, customers[i].name, customers[i].balance);
            return;
        }
    }
    printf("Customer with ID %d not found.\n", id);
}
*/

#include "searchCustomer.h"
#include <stdio.h>

void searchCustomer(Customer customers[], int count, int id) {
    for (int i = 0; i < count; i++) {
        if (customers[i].id == id) {
            printf("Customer found-----------\nID: %d\nName: %s\nBalance: %.2f\n", customers[i].id, customers[i].name, customers[i].balance);
            return;
        }
    }
    printf("Customer with ID %d not found.\n", id);
}
