/*#ifndef ADDCUSTOMER_H
#define ADDCUSTOMER_H

#include "structCustomer.h"

void addCustomer(Customer customers[], int *count);

#endif*/

#ifndef ADDCUSTOMER_H
#define ADDCUSTOMER_H

#include "structCustomer.h"

void addCustomer(Customer customers[], int *count);

#endif

