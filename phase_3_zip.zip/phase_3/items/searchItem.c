/*#include "structItemList.h"
#include <stdio.h>

void searchItem(ItemList items[], int count, int id) {
    for (int i = 0; i < count; i++) {
        if (items[i].id == id) {
            printf("Item found-----------\n Sr. Number: %d\n Name: %s\n Price: %.2f\n", items[i].id, items[i].name, items[i].price);
            return;
        }
    }
    printf("Items with Sr. number %d not found.\n", id);
}
*/


#include "structItemList.h"
#include <stdio.h>

void searchItem(ItemList items[], int count, int id) {
    for (int i = 0; i < count; i++) {
        if (items[i].id == id) {
            printf("Item found-----------\nSr. Number: %d\nName: %s\nPrice: %.2f\n", items[i].id, items[i].name, items[i].price);
            return;
        }
    }
    printf("Item with Sr. number %d not found.\n", id);
}
