#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ITEMS 100
#define ITEM_NAME_LEN 50
#define FILENAME "Items_Inventory.txt"

typedef struct 
{
    char name[ITEM_NAME_LEN];
    int id;
    double price;
} ItemList;