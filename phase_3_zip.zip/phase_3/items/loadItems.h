/*#ifndef LOADITEMS_H
#define LOADITEMS_H

#include "structItemList.h"

void loadItems(ItemList items[], int *count);

#endif*/


#ifndef LOADITEMS_H
#define LOADITEMS_H

#include "structItemList.h"

void loadItems(ItemList items[], int *count);

#endif