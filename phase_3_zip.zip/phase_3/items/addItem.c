/*#include "structItemList.h"
#include <stdio.h>

void addItem(ItemList items[], int *count)
{
    if (*count >= MAX_ITEMS)
    {
        printf("Item list is full.\n");
        return;
    }
    printf("Enter sr. number: ");
    scanf("%d", &items[*count].id);
    printf("Enter item name: ");
    scanf("%s", items[*count].name);
    printf("Enter item cost per unit: ");
    scanf("%lf", &items[*count].price);
    (*count)++;
    printf("Item added to inventory.\n");
}*/


#include "structItemList.h"
#include <stdio.h>

void addItem(ItemList items[], int *count)
{
    if (*count >= MAX_ITEMS)
    {
        printf("Item list is full.\n");
        return;
    }
    printf("Enter sr. number: ");
    scanf("%d", &items[*count].id);
    printf("Enter item name: ");
    scanf("%s", items[*count].name);
    printf("Enter item cost per unit: ");
    scanf("%lf", &items[*count].price);
    (*count)++;
    printf("Item added to inventory.\n");
}
