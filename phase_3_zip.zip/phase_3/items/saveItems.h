/*#ifndef SAVEITEMS_H
#define SAVEITEMS_H

#include "structItemList.h"

void saveItems(ItemList items[], int count);

#endif
*/


#ifndef SAVEITEMS_H
#define SAVEITEMS_H

#include "structItemList.h"

void saveItems(ItemList items[], int count);

#endif