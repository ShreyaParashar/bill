/*#ifndef ADDITEM_H
#define ADDITEM_H

#include "structItemList.h"

void addItem(ItemList items[], int *count);

#endif*/


#ifndef ADDITEM_H
#define ADDITEM_H

#include "structItemList.h"

void addItem(ItemList items[], int *count);

#endif
