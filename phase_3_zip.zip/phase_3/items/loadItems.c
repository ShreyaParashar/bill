/*#include "structItemList.h"
#include <stdio.h>

void loadItems(ItemList items[], int *count) {
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        printf("No no item inventory file found. Starting with an empty inventory.\n");
        return;
    }
    *count = 0;
    while (fscanf(file, "%d %s %lf", &items[*count].id, items[*count].name, &items[*count].price) != EOF) {
        (*count)++;
    }
    fclose(file);
    printf("Item details updated successfully.\n");
}*/


#include "structItemList.h"
#include <stdio.h>

void loadItems(ItemList items[], int *count) {
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        printf("No item inventory file found. Starting with an empty inventory.\n");
        return;
    }
    *count = 0;
    while (fscanf(file, "%d %s %lf", &items[*count].id, items[*count].name, &items[*count].price) != EOF) {
        (*count)++;
    }
    fclose(file);
    printf("Item details updated successfully.\n");
}