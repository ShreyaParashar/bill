/*#ifndef SEARCHITEM_H
#define SEARCHITEM_H

#include "structItemList.h"

void searchItem(ItemList items[], int count, int id);

#endif*/


#ifndef SEARCHITEM_H
#define SEARCHITEM_H

#include "structItemList.h"

void searchItem(ItemList items[], int count, int id);

#endif
