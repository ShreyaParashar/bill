/*#ifndef DISPLAYITEMS_H
#define DISPLAYITEMS_H

#include "structItemList.h";

void displayItems(ItemList items[], int count);

#endif*/


#ifndef DISPLAYITEMS_H
#define DISPLAYITEMS_H

#include "structItemList.h";

void displayItems(ItemList items[], int count);

#endif
