/*#include "structItemList.h"
#include <stdio.h>

void displayItems(ItemList items[], int count) 
{
    printf("\nInventory------------------\n");
    for (int i = 0; i < count; i++) 
    {
        printf("Sr. Number: %d\n Name: %s\n Unit Price: %.2f\n", items[i].id, items[i].name, items[i].price);
    }
}*/


#include "structItemList.h"
#include <stdio.h>

void displayItems(ItemList items[], int count) 
{
    printf("\nInventory------------------\n");
    for (int i = 0; i < count; i++) 
    {
        printf("Sr. Number: %d\nName: %s\nUnit Price: %.2f\n", items[i].id, items[i].name, items[i].price);
    }
}
